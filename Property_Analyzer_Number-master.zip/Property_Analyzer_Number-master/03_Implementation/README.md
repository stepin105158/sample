# Property Analyzer of a given number

This is an application which checks for various properties of a number. When a number is given, the application checks whether the number is:

1)Prime

2)Armstrong

3)Odd/Even

4)Palindrome

5)Power

6)Harshad

7)Perfect_square

8)Perfect_cube

9)Automorphic

10)Divisible by 3

11)Divisible by 5

12)Divisible by 7


[![Codacy Badge](https://api.codacy.com/project/badge/Grade/18e7aec979df4bb4a25a269fd72ada2f)](https://app.codacy.com/manual/99002496/Property_Analyzer_Number?utm_source=github.com&utm_medium=referral&utm_content=99002496/Property_Analyzer_Number&utm_campaign=Badge_Grade_Dashboard)

![C/C++ CI](https://github.com/99002496/Property_Analyzer_Number/workflows/C/C++%20CI/badge.svg)
![Unit testing](https://github.com/99002496/Property_Analyzer_Number/workflows/Unit%20testing/badge.svg?branch=master)
![cppcheck-action](https://github.com/99002496/Property_Analyzer_Number/workflows/cppcheck-action/badge.svg)

